#!/bin/bash
set -euo pipefail

PREFIX="${PREFIX:-$HOME/.local}"
echo "Installing airpods-helper to $PREFIX..."

install -Dm755 bin/airpods-daemon "$PREFIX/bin/airpods-daemon"
install -Dm755 bin/airpods-cli "$PREFIX/bin/airpods-cli"
install -Dm644 systemd/airpods-daemon.service "$HOME/.config/systemd/user/airpods-daemon.service"
install -Dm644 dbus/org.costa.AirPods.service "$HOME/.local/share/dbus-1/services/org.costa.AirPods.service"

install -dm755 "$HOME/.config/airpods-helper/eq/"
cp -n eq-presets/*.toml "$HOME/.config/airpods-helper/eq/" 2>/dev/null || true
cp -n config.example.toml "$HOME/.config/airpods-helper/config.toml" 2>/dev/null || true

systemctl --user daemon-reload

echo ""
echo "Installed. Next steps:"
echo "  sudo setcap 'cap_net_raw,cap_net_admin+eip' $PREFIX/bin/airpods-daemon"
echo "  systemctl --user enable --now airpods-daemon.service"
